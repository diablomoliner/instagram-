# cst_phishing-instagram
 Page de pishing Instagram
 
educational purposes

<b>JE NE SUIS PAS RESPONSABLE DE CE QUE VOUS FAITES AVEC CETTE RESSOURCE</b>
![cst_pishing-instagram](https://user-images.githubusercontent.com/78325525/151658318-0a2900a7-e57c-4d56-9286-313789bb2cd9.png)
